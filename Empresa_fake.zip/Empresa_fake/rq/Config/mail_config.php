<?php
return [
    'host'       => 'mail.pilsac.com.pe',
    'username'   => 'agenda@pilsac.com.pe',
    'password'   => 'Gts10203040*',
    'secure'     => 'ssl',
    'port'       => 465,
    'from_email' => 'agenda@pilsac.com.pe',
    'from_name'  => 'Sistema de Requerimientos',
    
    'bcc_email'  => 'cortezpompapriscila@gmail.com', 
    'bcc_name'   => 'Copia de Pruebas'
];