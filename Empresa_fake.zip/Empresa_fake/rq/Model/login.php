<?php
require_once __DIR__ . '/conexion.php';

class Usuario {
    public function login($correo, $contraseña) {
        global $conexion;
        try {
            $sql = "SELECT * FROM usuario WHERE correo = :correo AND contraseña = :contrasena";
            $stmt = $conexion->prepare($sql);
            $stmt->execute([
                ':correo' => $correo,
                ':contrasena' => $contraseña
            ]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            die("Error en la autenticación del usuario: " . $e->getMessage());
        }
    }
}
?>
