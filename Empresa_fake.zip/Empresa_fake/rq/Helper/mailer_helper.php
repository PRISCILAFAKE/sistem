<?php
// Helper/mailer_helper.php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/../include/PHPMailer/Exception.php';
require_once __DIR__ . '/../include/PHPMailer/PHPMailer.php';
require_once __DIR__ . '/../include/PHPMailer/SMTP.php';

function enviarCorreoSistema($destinatario_email, $destinatario_nombre, $asunto, $cuerpo_html, $archivo_adjunto = null, $reply_email = null, $reply_nombre = null) {
    $config = require __DIR__ . '/../Config/mail_config.php';

    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = $config['host'];
        $mail->SMTPAuth   = true;
        $mail->Username   = $config['username'];        
        $mail->Password   = $config['password'];    
        $mail->SMTPSecure = $config['secure'];
        $mail->Port       = $config['port'];

        // Remitente
        $mail->setFrom($config['from_email'], $config['from_name']);

        // Destinatario Principal
        $mail->addAddress($destinatario_email, $destinatario_nombre);

        // Responder a (opcional)
        if (!empty($reply_email) && $reply_email !== 'No registrado') {
            $mail->addReplyTo($reply_email, $reply_nombre ?? '');
        }

        // Archivo adjunto (opcional)
        if (!empty($archivo_adjunto) && file_exists($archivo_adjunto)) {
            $mail->addAttachment($archivo_adjunto);
        }

        // CCO (BCC) Global Automático -> Aquí llegará tu copia a cortezpompapriscila@gmail.com
        if (!empty($config['bcc_email'])) {
            $mail->addBCC($config['bcc_email'], $config['bcc_name']);
        }

        // Contenido
        $mail->isHTML(true);
        $mail->Subject = $asunto;
        $mail->Body    = $cuerpo_html;

        $mail->send();
        return true;
    } catch (Exception $e) {
        return false;
    }
}