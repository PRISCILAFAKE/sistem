<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio Sesión</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container d-flex justify-content-center align-items-center vh-100">
        <div class="card p-4 shadow" style="width: 25rem;">
            <h3 class="text-center mb-4">Iniciar Sesión</h3>
            <form action="Controller/login_controller.php" method="POST">
                <div class="mb-3">
                    <label for="email" class="form-label">Usuario:</label>
                    <input type="email" name="correo_usuario" class="form-control" placeholder="Ej. tunombre@gmail.com" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Contraseña:</label>
                    <input type="password" class="form-control" name="contraseña_usuario" placeholder="Ingresa tu contraseña" required>
                </div>

                <button type="submit" class="btn btn-primary w-100">Continuar</button>
            </form>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>