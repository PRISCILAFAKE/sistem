<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../Model/conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_usuario = $_POST['id_usuario'] ?? null;
    $nombre     = $_POST['nombre'] ?? '';
    $correo     = $_POST['correo'] ?? '';
    $contrasena = $_POST['contrasena'] ?? '';
    $rol        = $_POST['rol'] ?? '';
    $id_area_fk = !empty($_POST['id_area']) ? $_POST['id_area'] : null;

    if ($id_usuario) {
        try {
            $sql = "UPDATE usuario SET nombre = :nombre, correo = :correo, contraseña = :contrasena, rol = :rol, id_area_fk = :id_area_fk WHERE id_usuario = :id";
            $stmt = $conexion->prepare($sql);
            $stmt->execute([
                ':nombre'     => $nombre,
                ':correo'     => $correo,
                ':contrasena' => $contrasena,
                ':rol'        => $rol,
                ':id_area_fk' => $id_area_fk,
                ':id'         => $id_usuario
            ]);

            header("Location: ../View/crear_usuario_view.php?actualizacion=exitoso");
            exit();
        } catch (PDOException $e) {
            $errorMensaje = urlencode("Error al actualizar: " . $e->getMessage());
            header("Location: ../View/editar_usuario_view.php?id=" . $id_usuario . "&error=" . $errorMensaje);
            exit();
        }
    }
}

header("Location: ../View/crear_usuario_view.php");
exit();
?>