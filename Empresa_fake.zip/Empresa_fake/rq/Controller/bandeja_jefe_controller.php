<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../Model/conexion.php';

try {
    $id_jefe = $_SESSION['id_usuario'] ?? null;

    if (!$id_jefe) {
        throw new Exception("No hay sesión activa.");
    }

    $stmt_jefe = $conexion->prepare("SELECT id_area_fk FROM usuario WHERE id_usuario = ? AND es_jefe = 1");
    $stmt_jefe->execute([$id_jefe]);
    $datos_jefe = $stmt_jefe->fetch(PDO::FETCH_ASSOC);

    $requerimientos = [];

    if ($datos_jefe) {
        $id_area = $datos_jefe['id_area_fk'];

        $sql = "SELECT r.*, u.nombre AS nombre_usuario, urg.urgencia AS nombre_urgencia 
                FROM requerimientos r 
                INNER JOIN usuario u ON r.id_usuario_f = u.id_usuario 
                LEFT JOIN urgencia urg ON r.id_urgencia_fk = urg.id_urgencia
                WHERE u.id_area_fk = ? AND r.estado = 'pendiente_jefe'
                ORDER BY r.id_requerimiento DESC";

        $stmt = $conexion->prepare($sql);
        $stmt->execute([$id_area]);
        $requerimientos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

} catch (Exception $e) {
    $requerimientos = [];
}
?>