<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../Model/conexion.php';

$id_usuario_actual = $_SESSION['id_usuario'] ?? null;

if (!$id_usuario_actual) {
    header("Location: ../View/login_view.php");
    exit();
}

$nombre_buscado = $_GET['nombre_buscado'] ?? '';
$requerimientos = [];

try {
    $sql = "SELECT r.*, 
                   t.nombre_s AS nombre_tipo_solicitud, 
                   u.nombre_ur AS nombre_urgencia, 
                   p.estado 
            FROM requerimientos r 
            LEFT JOIN tipo_solicitud t ON r.id_tipo_solicitud_fk = t.id_tipos 
            LEFT JOIN urgencia u ON r.id_urgencia_fk = u.id_urgencia 
            LEFT JOIN procesos p ON r.id_requerimiento = p.id_requerimiento_fk 
            WHERE r.id_usuario_f = :id_usuario";

    if (!empty($nombre_buscado)) {
        $sql .= " AND r.nombre_solicitud LIKE :nombre_buscado";
    }

    $sql .= " ORDER BY r.fecha DESC";

    $stmt = $conexion->prepare($sql);
    
    $params = [':id_usuario' => $id_usuario_actual];
    if (!empty($nombre_buscado)) {
        $params[':nombre_buscado'] = '%' . $nombre_buscado . '%';
    }

    $stmt->execute($params);
    $requerimientos = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $error_mensaje = "Error al obtener el historial: " . $e->getMessage();
}
?>