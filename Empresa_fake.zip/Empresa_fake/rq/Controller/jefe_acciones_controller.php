<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../Model/conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_requerimiento = $_POST['id_requerimiento'] ?? null;
    $accion = $_POST['accion'] ?? null;
    $motivo_rechazo = $_POST['motivo_rechazo'] ?? null;

    if ($id_requerimiento && $accion) {
        try {
            if ($accion === 'aceptar') {
                // Pasa gerencia
                $stmt = $conexion->prepare("UPDATE requerimientos SET estado = 'pendiente_gerencia' WHERE id_requerimiento = ?");
                $stmt->execute([$id_requerimiento]);
            } elseif ($accion === 'rechazar') {
                $stmt = $conexion->prepare("UPDATE requerimientos SET estado = 'rechazado', motivo_rechazo = ? WHERE id_requerimiento = ?");
                $stmt->execute([$motivo_rechazo, $id_requerimiento]);
            }
            
            header("Location: ../View/bandeja_jefe_view.php");
            exit();
        } catch (Exception $e) {
            die("Error al procesar la acción: " . $e->getMessage());
        }
    }
}
?>