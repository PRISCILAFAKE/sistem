<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../Model/conexion.php';

$id_usuario_actual = $_SESSION['id_usuario'] ?? null;
if (!$id_usuario_actual) {
    header("Location: ../View/login_view.php");
    exit();
}

try {

$sql = "SELECT r.*, u.nombre AS nombre_usuario, a.nombre_area,
                   COALESCE(urg.nombre_ur, 'Normal') AS nombre_urgencia
            FROM requerimientos r
            LEFT JOIN usuario u ON r.id_usuario_f = u.id_usuario
            LEFT JOIN areas a ON u.id_area_fk = a.id_area
            LEFT JOIN urgencia urg ON r.id_urgencia_fk = urg.id_urgencia
            WHERE LOWER(TRIM(r.estado)) = 'pendiente_gerencia'
            ORDER BY r.id_requerimiento DESC";

    $stmt = $conexion->prepare($sql);
    $stmt->execute();
    $requerimientos = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $requerimientos = [];
    $error_db = "Error al cargar las solicitudes: " . $e->getMessage();
}