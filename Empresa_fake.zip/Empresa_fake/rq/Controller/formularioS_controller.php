<?php
session_start();
require_once __DIR__ . '/../Model/conexion.php';
require_once __DIR__ . '/../Helper/mailer_helper.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_tipo_solicitud_fk = $_POST['id_tipo_solicitud_fk']; 
    $id_urgencia_fk = $_POST['id_urgencia_fk']; 
    $fecha = $_POST['fecha'];
    $funcionalidad = $_POST['funcionalidad'];
    $necesidad = $_POST['necesidad'];
    $impacto_user = $_POST['impacto_user'];
    $areas_afectadas = isset($_POST['areas_afectadas']) ? implode(', ', $_POST['areas_afectadas']) : '';
    $area_solicitante = $_SESSION['user'] ?? 'Desconocido';
    $correo_solicitante = $_SESSION['correo'] ?? 'No registrado';
    $nombre_solicitud = $_POST['nombre_solicitud'];
    
    $id_usuario_f = $_SESSION['id_usuario'] ?? null;

    $rutaArchivoDestino = null;    
    $rutaParaBD = null;            

    if (isset($_FILES['archivo']) && $_FILES['archivo']['error'] === UPLOAD_ERR_OK) {
        $nombreOriginal = $_FILES['archivo']['name'];
        $tmpName = $_FILES['archivo']['tmp_name'];
        
        $nombreUnico = uniqid() . '_' . basename($nombreOriginal);
        $directorioSubidas = __DIR__ . '/../uploads/';
        
        if (!is_dir($directorioSubidas)) {
            mkdir($directorioSubidas, 0755, true);
        }
        
        $rutaArchivoDestino = $directorioSubidas . $nombreUnico;
        
        if (move_uploaded_file($tmpName, $rutaArchivoDestino)) {
            $rutaParaBD = 'uploads/' . $nombreUnico;
        }
    }

    try {
        $conexion->beginTransaction();

        $stmt_area = $conexion->prepare("
            SELECT u_empleado.id_area_fk, 
                   (SELECT u_jefe.id_usuario 
                    FROM usuario u_jefe 
                    WHERE u_jefe.id_area_fk = u_empleado.id_area_fk 
                      AND u_jefe.es_jefe = 1 
                    LIMIT 1) AS id_jefe
            FROM usuario u_empleado 
            WHERE u_empleado.id_usuario = ?
        ");
        $stmt_area->execute([$id_usuario_f]);
        $datos_usuario = $stmt_area->fetch(PDO::FETCH_ASSOC);

        if (!empty($datos_usuario['id_jefe'])) {
            $estado_inicial = 'pendiente_jefe'; 
        } else {
            $estado_inicial = 'pendiente_gerencia'; 
        }

        $sql = "INSERT INTO requerimientos (id_tipo_solicitud_fk, id_urgencia_fk, fecha, funcionalidad, necesidad, impacto_user, areas_afectadas, area_solicitante, nombre_solicitud, id_usuario_f, archivo_adjunto, estado) 
                VALUES (:id_tipo_solicitud_fk, :id_urgencia_fk, :fecha, :funcionalidad, :necesidad, :impacto_user, :areas_afectadas, :area_solicitante, :nombre_solicitud, :id_usuario_f, :archivo_adjunto, :estado)";
        
        $stmt = $conexion->prepare($sql);
        $stmt->execute([
            ':id_tipo_solicitud_fk' => $id_tipo_solicitud_fk,
            ':id_urgencia_fk' => $id_urgencia_fk,
            ':fecha' => $fecha,
            ':funcionalidad' => $funcionalidad,
            ':necesidad' => $necesidad,
            ':impacto_user' => $impacto_user,
            ':areas_afectadas' => $areas_afectadas,
            ':area_solicitante' => $area_solicitante,
            ':nombre_solicitud' => $nombre_solicitud,
            ':id_usuario_f' => $id_usuario_f,
            ':archivo_adjunto' => $rutaParaBD,
            ':estado' => $estado_inicial
        ]);

        $id_nuevo_requerimiento = $conexion->lastInsertId();
        
        $sqlProceso = "INSERT INTO procesos (id_requerimiento_fk, estado) VALUES (:id_req, :estado)";
        $stmtProceso = $conexion->prepare($sqlProceso);
        $stmtProceso->execute([
            ':id_req' => $id_nuevo_requerimiento,
            ':estado' => $estado_inicial
        ]);

        $conexion->commit();

    } catch (PDOException $e) {
        if ($conexion->inTransaction()) {
            $conexion->rollBack();
        }
        die("Error al guardar en la BD: " . $e->getMessage());
    }

    try {
        if ($estado_inicial === 'pendiente_jefe' && !empty($datos_usuario['id_jefe'])) {
            $stmtJefeCorreo = $conexion->prepare("SELECT correo, nombre FROM usuario WHERE id_usuario = ?");
            $stmtJefeCorreo->execute([$datos_usuario['id_jefe']]);
            $jefeData = $stmtJefeCorreo->fetch(PDO::FETCH_ASSOC);
            $correoDestino = $jefeData['correo'] ?? 'priscilacortez353@gmail.com';
            $nombreDestino = $jefeData['nombre'] ?? 'Jefe de Área';
        } else {
            $sqlDestinatario = "SELECT correo, nombre FROM usuario WHERE rol = 'gerencia' OR rol = 'gerente' LIMIT 1";
            $stmtDestinatario = $conexion->query($sqlDestinatario);
            $destinatarioData = $stmtDestinatario->fetch(PDO::FETCH_ASSOC);
            $correoDestino = $destinatarioData['correo'] ?? 'priscilacortez353@gmail.com'; 
            $nombreDestino = $destinatarioData['nombre'] ?? 'Gerencia';
        }

        if (!empty($fecha)) {
            $timestamp = strtotime($fecha);
            $dia = date('j', $timestamp); 
            $meses = ['', 'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
            $mes = $meses[date('n', $timestamp)];
            $anio = date('Y', $timestamp);
            
            $fechaFormateadaParaCorreo = "$dia de $mes $anio";
        } else {
            $fechaFormateadaParaCorreo = 'No especificada';
        }

        $asunto = "Nuevo Requerimiento: " . $nombre_solicitud;
        $cuerpo = "Se ha registrado un nuevo requerimiento.<br><br>
                   <b>Solicitante:</b> {$area_solicitante} ({$correo_solicitante}) <br>
                   <b>Nombre de Solicitud:</b> {$nombre_solicitud} <br>
                   <b>Fecha:</b> {$fechaFormateadaParaCorreo} <br>
                   <b>Áreas Afectadas:</b> {$areas_afectadas} <br>
                   <b>Flujo Inicial:</b> {$estado_inicial}";

        enviarCorreoSistema(
            $correoDestino, 
            $nombreDestino, 
            $asunto, 
            $cuerpo, 
            $rutaArchivoDestino, 
            $correo_solicitante, 
            $area_solicitante
        );

    } catch (Exception $e) {

    }

    header("Location: ../View/solicitud_view.php");
    exit();
}
?>