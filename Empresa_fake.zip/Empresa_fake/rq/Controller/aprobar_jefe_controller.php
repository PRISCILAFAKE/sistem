<?php
session_start();
require_once __DIR__ . '/../Model/conexion.php';

if (!isset($_SESSION['id_usuario']) || empty($_SESSION['es_jefe']) || $_SESSION['es_jefe'] != 1) {
    header("Location: ../index.php");
    exit();
}

$id_requerimiento = $_POST['id_requerimiento'] ?? null;

if ($id_requerimiento) {
    try {
        $conexion->beginTransaction();

        $sql = "UPDATE requerimientos SET estado = 'pendiente_gerencia' WHERE id_requerimiento = :id";
        $stmt = $conexion->prepare($sql);
        $stmt->execute([':id' => $id_requerimiento]);

        $sqlCheck = "SELECT COUNT(*) FROM procesos WHERE id_requerimiento_fk = :id_req";
        $stmtCheck = $conexion->prepare($sqlCheck);
        $stmtCheck->execute([':id_req' => $id_requerimiento]);
        $existe = $stmtCheck->fetchColumn();

        if ($existe > 0) {
            $sqlProceso = "UPDATE procesos SET estado = 'pendiente_gerencia', fecha_actualizada = NOW() WHERE id_requerimiento_fk = :id_req";
        } else {
            $sqlProceso = "INSERT INTO procesos (id_requerimiento_fk, estado, fecha_actualizada) VALUES (:id_req, 'pendiente_gerencia', NOW())";
        }
        $stmtProceso = $conexion->prepare($sqlProceso);
        $stmtProceso->execute([':id_req' => $id_requerimiento]);

        $conexion->commit();
    } catch (PDOException $e) {
        if ($conexion->inTransaction()) {
            $conexion->rollBack();
        }
        die("Error al aprobar: " . $e->getMessage());
    }
}

header("Location: ../View/bandeja_jefe_view.php");
exit();
?>