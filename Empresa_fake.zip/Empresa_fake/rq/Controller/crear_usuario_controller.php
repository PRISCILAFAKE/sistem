<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../Model/conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre     = $_POST['nombre'] ?? '';
    $correo     = $_POST['correo'] ?? '';
    $contrasena = $_POST['contrasena'] ?? '';
    $rol        = $_POST['rol'] ?? '';
    $id_area_fk = !empty($_POST['id_area']) ? $_POST['id_area'] : null;

    try {
        
        $sql = "INSERT INTO usuario (nombre, correo, contraseña, rol, id_area_fk, estado) 
                VALUES (:nombre, :correo, :contrasena, :rol, :id_area_fk, 'activo')";
        
        $stmt = $conexion->prepare($sql);
        $stmt->execute([
            ':nombre'     => $nombre,
            ':correo'     => $correo,
            ':contrasena' => $contrasena,
            ':rol'        => $rol,
            ':id_area_fk' => $id_area_fk
        ]);

        header("Location: ../View/crear_usuario_view.php?registro=exitoso");
        exit();

    } catch (PDOException $e) {
        $errorMensaje = urlencode("Error en la Base de Datos: " . $e->getMessage());
        header("Location: ../View/crear_usuario_view.php?error=" . $errorMensaje);
        exit();
    }
} else {
    try {
       
        $sqlUsuarios = "SELECT u.id_usuario, u.nombre, u.correo, u.contraseña, u.rol, u.estado, a.nombre_area 
                        FROM usuario u 
                        LEFT JOIN areas a ON u.id_area_fk = a.id_area 
                        ORDER BY u.id_usuario DESC";
        $stmtUsuarios = $conexion->query($sqlUsuarios);
        
        $_SESSION['lista_usuarios'] = $stmtUsuarios->fetchAll(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
        $_SESSION['lista_usuarios'] = [];
    }

    header("Location: ../View/crear_usuario_view.php");
    exit();
}
?>