<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../Model/conexion.php';

$id_usuario = $_GET['id'] ?? null;
$nuevo_estado = $_GET['estado'] ?? null;

if ($id_usuario && in_array($nuevo_estado, ['activo', 'inactivo'])) {
    try {
        $sql = "UPDATE usuario SET estado = :estado WHERE id_usuario = :id";
        $stmt = $conexion->prepare($sql);
        $stmt->execute([
            ':estado' => $nuevo_estado,
            ':id'     => $id_usuario
        ]);
    } catch (PDOException $e) {
        die("Error al actualizar el estado del usuario: " . $e->getMessage());
    }
}

header("Location: ../View/crear_usuario_view.php");
exit();
?>