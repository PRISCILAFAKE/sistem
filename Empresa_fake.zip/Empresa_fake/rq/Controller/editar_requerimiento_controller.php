<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../Model/conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_requerimiento = $_POST['id_requerimiento'] ?? null;
    $nombre_solicitud = $_POST['nombre_solicitud'] ?? '';
    $funcionalidad    = $_POST['funcionalidad'] ?? '';
    $necesidad        = $_POST['necesidad'] ?? '';
    $impacto_user     = $_POST['impacto_user'] ?? 0;
    
    $areas_afectadas  = isset($_POST['areas_afectadas']) ? implode(', ', $_POST['areas_afectadas']) : '';

    if ($id_requerimiento) {
        try {
            $conexion->beginTransaction();

            $sql_req = "UPDATE requerimientos 
                        SET nombre_solicitud = :nombre, 
                            funcionalidad = :funcionalidad, 
                            necesidad = :necesidad, 
                            impacto_user = :impacto, 
                            areas_afectadas = :areas 
                        WHERE id_requerimiento = :id";
            
            $stmt = $conexion->prepare($sql_req);
            $stmt->execute([
                ':nombre'        => $nombre_solicitud,
                ':funcionalidad' => $funcionalidad,
                ':necesidad'     => $necesidad,
                ':impacto'       => $impacto_user,
                ':areas'         => $areas_afectadas,
                ':id'            => $id_requerimiento
            ]);

            $sql_proc = "UPDATE procesos SET estado = 'registrado', motivo_rechazo = NULL WHERE id_requerimiento_fk = :id";
            $stmt_proc = $conexion->prepare($sql_proc);
            $stmt_proc->execute([':id' => $id_requerimiento]);

            $conexion->commit();

            header("Location: ../View/solicitud_view.php?reenviado=1");
            exit();

        } catch (Exception $e) {
            $conexion->rollBack();
            echo "Error al actualizar el requerimiento: " . $e->getMessage();
        }
    } else {
        header("Location: ../View/solicitud_view.php");
        exit();
    }
}
?>