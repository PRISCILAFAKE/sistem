<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../Model/conexion.php';

try {
    $stmt_usr = $conexion->prepare("SELECT id_usuario, nombre AS nombre_usuario FROM usuario");
    $stmt_usr->execute();
    $usuarios = $stmt_usr->fetchAll(PDO::FETCH_ASSOC);

    $where = [];
    $params = [];

    if (!empty($_GET['id_buscado'])) {
        $where[] = "nombre_solicitud LIKE ?";
        $params[] = "%" . $_GET['id_buscado'] . "%";
    }

    if (!empty($_GET['id_usuario_f'])) {
        $where[] = "r.id_usuario_f = ?";
        $params[] = $_GET['id_usuario_f'];
    }

    $sql = "SELECT r.*, u.nombre AS nombre_usuario FROM requerimientos r LEFT JOIN usuario u ON r.id_usuario_f = u.id_usuario";
    
    if (!empty($where)) {
        $sql .= " WHERE " . implode(" AND ", $where);
    }
    
    $sql .= " ORDER BY r.id_requerimiento DESC";

    $stmt = $conexion->prepare($sql);
    $stmt->execute($params);
    $requerimientos = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    $error_msg = "Error al cargar los datos: " . $e->getMessage();
    $requerimientos = [];
    $usuarios = [];
}
?>