<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../Model/conexion.php';
require_once __DIR__ . '/../Helper/mailer_helper.php';

$id_usuario_actual = $_SESSION['id_usuario'] ?? null;
if (!$id_usuario_actual) {
    header("Location: ../View/login_view.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_requerimiento = $_POST['id_requerimiento'] ?? null;
    $motivo_rechazo = $_POST['motivo_rechazo'] ?? null;

    if ($id_requerimiento && !empty(trim($motivo_rechazo))) {
        try {
            $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $sqlMotivo = "UPDATE requerimientos SET motivo_rechazo = :motivo WHERE id_requerimiento = :id_req";
            $stmtMotivo = $conexion->prepare($sqlMotivo);
            $stmtMotivo->execute([
                ':motivo' => trim($motivo_rechazo),
                ':id_req' => $id_requerimiento
            ]);

            $sqlCheck = "SELECT id_proceso FROM procesos WHERE id_requerimiento_fk = :id_req";
            $stmtCheck = $conexion->prepare($sqlCheck);
            $stmtCheck->execute([':id_req' => $id_requerimiento]);
            $proceso = $stmtCheck->fetch(PDO::FETCH_ASSOC);

            if ($proceso) {
                $sqlProc = "UPDATE procesos SET estado = 'rechazado', fecha_actualizada = NOW() WHERE id_requerimiento_fk = :id_req";
                $stmtProc = $conexion->prepare($sqlProc);
                $stmtProc->execute([':id_req' => $id_requerimiento]);
            } else {
                $sqlProc = "INSERT INTO procesos (id_requerimiento_fk, estado, fecha_actualizada) VALUES (:id_req, 'rechazado', NOW())";
                $stmtProc = $conexion->prepare($sqlProc);
                $stmtProc->execute([':id_req' => $id_requerimiento]);
            }

            $sqlUser = "SELECT u.correo, u.nombre, r.nombre_solicitud 
                        FROM requerimientos r 
                        INNER JOIN usuario u ON r.id_usuario_f = u.id_usuario 
                        WHERE r.id_requerimiento = :id_req";
            $stmtUser = $conexion->prepare($sqlUser);
            $stmtUser->execute([':id_req' => $id_requerimiento]);
            $datosUsuario = $stmtUser->fetch(PDO::FETCH_ASSOC);

            if ($datosUsuario && !empty($datosUsuario['correo'])) {
                $asunto = "Requerimiento Rechazado: " . $datosUsuario['nombre_solicitud'];
                $cuerpo = "Hola <b>" . htmlspecialchars($datosUsuario['nombre']) . "</b>,<br><br>
                           Lamentamos informarle que su requerimiento <b>" . htmlspecialchars($datosUsuario['nombre_solicitud']) . "</b> ha sido <b>rechazado</b> por gerencia.<br><br>
                           <b>Motivo del rechazo:</b><br>
                           <p style='color: red;'>" . nl2br(htmlspecialchars($motivo_rechazo)) . "</p><br>
                           Puede ingresar al sistema para editar su requerimiento y volver a enviarlo.<br><br>
                           Atentamente,<br>
                           <b>Gerencia</b>";

                enviarCorreoSistema($datosUsuario['correo'], $datosUsuario['nombre'], $asunto, $cuerpo);
            }

            header("Location: ../View/solicitud_ge_view.php?rechazado=1");
            exit();

        } catch (PDOException $e) {
            die("Error en la Base de Datos: " . $e->getMessage());
        } catch (Exception $e) {
            die("El requerimiento fue rechazado, pero ocurrió un error al enviar el correo.");
        }
    } else {
        header("Location: ../View/solicitud_ge_view.php?error=Falta_motivo");
        exit();
    }
} else {
    header("Location: ../View/solicitud_ge_view.php");
    exit();
}