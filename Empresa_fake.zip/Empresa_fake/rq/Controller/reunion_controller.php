<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../Model/conexion.php';

require_once __DIR__ . '/../include/PHPMailer/Exception.php';
require_once __DIR__ . '/../include/PHPMailer/PHPMailer.php';
require_once __DIR__ . '/../include/PHPMailer/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_requerimiento = $_POST['id_requerimiento'] ?? null; 
    $fecha            = $_POST['fecha'];
    $hora             = $_POST['hora'];
    $asunto           = $_POST['asunto'];
    $destinatarios    = $_POST['para'] ?? ''; 
    $descripcion      = $_POST['descripcion'] ?? '';
    
    $nombre_admin     = $_SESSION['user'] ?? 'Administrador';
    $correo_admin     = $_SESSION['correo'] ?? 'agenda@pilsac.com.pe';
    
    $nombre_archivo = '';
    $ruta_archivo = '';

    if (isset($_FILES['archivo']) && $_FILES['archivo']['error'] === UPLOAD_ERR_OK) {
        $nombre_archivo = time() . '_' . basename($_FILES['archivo']['name']);
        $carpeta_destino = __DIR__ . '/../uploads/';
        
        if (!file_exists($carpeta_destino)) {
            mkdir($carpeta_destino, 0777, true);
        }
        
        $ruta_archivo = $carpeta_destino . $nombre_archivo;
        move_uploaded_file($_FILES['archivo']['tmp_name'], $ruta_archivo);
    }

    $listaCorreosCrudos = explode(',', $destinatarios);
    $correosValidos = [];

    foreach ($listaCorreosCrudos as $correo) {
        $correoLimpio = trim($correo);
        if (filter_var($correoLimpio, FILTER_VALIDATE_EMAIL)) {
            $correosValidos[] = $correoLimpio;
        }
    }

    if (empty($correosValidos)) {
        die("Error: No se ingresó ningún correo electrónico válido.");
    }

    if (!$id_requerimiento) {
        die("Error: No se especificó el ID del requerimiento.");
    }

    try {
        $sql = "INSERT INTO reuniones (id_requerimiento_fk, fecha, hora, asunto, descripcion, archivo, para) VALUES (:id_requerimiento_fk, :fecha, :hora, :asunto, :descripcion, :archivo, :para)";
        $stmt = $conexion->prepare($sql);

        $stmt->execute([
            ':id_requerimiento_fk' => $id_requerimiento,
            ':fecha'               => $fecha,
            ':hora'                => $hora,
            ':asunto'              => $asunto,
            ':descripcion'         => $descripcion,
            ':archivo'             => $nombre_archivo,
            ':para'                => $destinatarios
        ]);

        if (!empty($fecha)) {
            $timestamp = strtotime($fecha);
            $dia = date('j', $timestamp); 
            $meses = ['', 'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
            $mes = $meses[date('n', $timestamp)];
            $anio = date('Y', $timestamp);
            
            $fechaFormateadaParaCorreo = "$dia de $mes $anio";
        } else {
            $fechaFormateadaParaCorreo = 'No especificada';
        }

        $mail = new PHPMailer(true);

        $mail->isSMTP();
        $mail->Host       = 'mail.pilsac.com.pe';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'agenda@pilsac.com.pe';        
        $mail->Password   = 'Gts10203040*';    
        $mail->SMTPSecure = 'ssl';
        $mail->Port       = 465;

        $mail->setFrom('agenda@pilsac.com.pe', 'Reunión programada por: ' . $nombre_admin);

        foreach ($correosValidos as $correoDestino) {
            $mail->addAddress($correoDestino);
        }                

        if (!empty($correo_admin)) {
            $mail->addReplyTo($correo_admin, $nombre_admin);
        }

        if (!empty($ruta_archivo) && file_exists($ruta_archivo)) {
            $mail->addAttachment($ruta_archivo, $nombre_archivo);
        }
        $mail->CharSet = 'UTF-8';
        $mail->isHTML(true);
        $mail->Subject = "Nueva Reunión Programada: " . $asunto;
        $mail->Body    = "Se ha registrado una nueva reunión con los siguientes datos:<br><br>
                          <b>Organizador:</b> {$nombre_admin} ({$correo_admin}) <br>
                          <b>Asunto:</b> {$asunto} <br>
                          <b>Fecha:</b> {$fechaFormateadaParaCorreo} <br>
                          <b>Hora:</b> {$hora} <br><br>
                          <b>Breve descripción:</b><br>{$descripcion}";

        $mail->send();

        header("Location: ../View/solicitud_crud_view.php");
        exit();

    } catch (PDOException $e) {
        die("Error al guardar la reunión en la BD: " . $e->getMessage());
    } catch (Exception $e) {
        die("La reunión se guardó, pero no se pudo enviar el correo: " . $mail->ErrorInfo);
    }
}
?>