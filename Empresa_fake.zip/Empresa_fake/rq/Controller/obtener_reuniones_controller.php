<?php
session_start();
require_once __DIR__ . '/../Model/conexion.php';

$id_requerimiento = $_GET['id_requerimiento'] ?? null;

if (!$id_requerimiento) {
    echo '<div class="alert alert-warning text-center">ID de requerimiento no válido.</div>';
    exit();
}

try {
    $stmt = $conexion->prepare("SELECT * FROM reuniones WHERE id_requerimiento_fk = :id_req ORDER BY fecha DESC, hora DESC");
    $stmt->execute([':id_req' => $id_requerimiento]);
    $reuniones = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!empty($reuniones)) {
        echo '<div class="table-responsive">
                <table class="table table-hover align-middle mb-0" style="font-size: 14px;">
                    <thead class="table-light text-uppercase fs-7 text-secondary border-bottom">
                        <tr>
                            <th class="py-3 ps-3">Asunto / Descripción</th>
                            <th class="py-3">Fecha y Hora</th>
                            <th class="py-3">Destinatarios</th>
                            <th class="py-3 text-center">Archivo</th>
                        </tr>
                    </thead>
                    <tbody>';
        
        foreach ($reuniones as $reunion) {
            $asunto = htmlspecialchars($reunion['asunto'] ?? 'Sin asunto');
            $fecha = htmlspecialchars($reunion['fecha'] ?? '');
            $hora = htmlspecialchars($reunion['hora'] ?? '');
            $destinatariosCrudos = $reunion['para'] ?? '';
            $descripcion = htmlspecialchars($reunion['descripcion'] ?? 'Sin descripción');
            $archivo = $reunion['archivo'] ?? '';

            $fechaFormateada = $fecha;
            if (!empty($fecha)) {
                $timestamp = strtotime($fecha);
                $meses = ['', 'Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
                $fechaFormateada = date('d', $timestamp) . ' ' . $meses[date('n', $timestamp)] . ' ' . date('Y', $timestamp);
            }

            $badgesCorreos = '';
            if (!empty($destinatariosCrudos)) {
                $arrayCorreos = explode(',', $destinatariosCrudos);
                foreach ($arrayCorreos as $correo) {
                    $correoLimpio = trim($correo);
                    if (!empty($correoLimpio)) {
                        $badgesCorreos .= '<span class="badge bg-light text-dark border me-1 mb-1 fw-normal" style="font-size: 12px;">
                                             <i class="bi bi-envelope text-primary me-1"></i>' . htmlspecialchars($correoLimpio) . '
                                           </span>';
                    }
                }
            } else {
                $badgesCorreos = '<span class="text-muted small fst-italic">No especificado</span>';
            }

            echo '<tr>
                    <td class="ps-3 py-3" style="width: 35%;">
                        <div class="fw-bold text-dark mb-1">' . $asunto . '</div>
                        <div class="text-muted small text-wrap" style="max-width: 350px;">' . $descripcion . '</div>
                    </td>
                    <td class="py-3 text-nowrap" style="width: 20%;">
                        <div class="fw-semibold text-dark"><i class="bi bi-calendar3 text-primary me-1"></i> ' . $fechaFormateada . '</div>
                        <div class="text-muted small"><i class="bi bi-clock text-warning me-1"></i> ' . $hora . '</div>
                    </td>
                    <td class="py-3" style="width: 30%;">
                        <div class="d-flex flex-wrap">
                            ' . $badgesCorreos . '
                        </div>
                    </td>
                    <td class="py-3 text-center text-nowrap" style="width: 15%;">';
            
            if (!empty($archivo)) {
                echo '<a href="../uploads/' . htmlspecialchars($archivo) . '" target="_blank" class="btn btn-sm btn-light border text-dark px-2 py-1" title="Ver archivo adjunto">
                        <i class="bi bi-paperclip text-primary"></i> <span class="small">Ver</span>
                      </a>';
            } else {
                echo '<span class="text-muted small fst-italic">Ninguno</span>';
            }

            echo '  </td>
                  </tr>';
        }
        
        echo '      </tbody>
                </table>
              </div>';
    } else {
        echo '<div class="text-center py-5">
                <div class="mb-2">
                    <i class="bi bi-calendar-x text-muted" style="font-size: 2.5rem;"></i>
                </div>
                <p class="text-muted m-0">No hay reuniones registradas para este requerimiento.</p>
              </div>';
    }

} catch (PDOException $e) {
    echo '<div class="alert alert-danger text-center mb-0">Error al cargar las reuniones: ' . htmlspecialchars($e->getMessage()) . '</div>';
}
?>