<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../Model/conexion.php';

header('Content-Type: application/json');

$id_usuario_actual = $_SESSION['id_usuario'] ?? null;
$term = $_GET['term'] ?? '';

if (!$id_usuario_actual || empty(trim($term))) {
    echo json_encode([]);
    exit();
}

try {
    $sql = "SELECT DISTINCT nombre_solicitud 
            FROM requerimientos 
            WHERE id_usuario_f = :id_usuario 
            AND nombre_solicitud LIKE :term 
            LIMIT 5"; 

    $stmt = $conexion->prepare($sql);
    $stmt->execute([
        ':id_usuario' => $id_usuario_actual,
        ':term' => '%' . $term . '%'
    ]);

    $resultados = $stmt->fetchAll(PDO::FETCH_COLUMN);
    echo json_encode($resultados);

} catch (PDOException $e) {
    echo json_encode([]);
}
?><?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../Model/conexion.php';

header('Content-Type: application/json');

$id_usuario_actual = $_SESSION['id_usuario'] ?? null;
$term = $_GET['term'] ?? '';

if (!$id_usuario_actual || empty(trim($term))) {
    echo json_encode([]);
    exit();
}

try {
    $sql = "SELECT DISTINCT nombre_solicitud 
            FROM requerimientos 
            WHERE id_usuario_f = :id_usuario 
            AND nombre_solicitud LIKE :term 
            LIMIT 5";

    $stmt = $conexion->prepare($sql);
    $stmt->execute([
        ':id_usuario' => $id_usuario_actual,
        ':term' => '%' . $term . '%'
    ]);

    $resultados = $stmt->fetchAll(PDO::FETCH_COLUMN);
    echo json_encode($resultados);

} catch (PDOException $e) {
    echo json_encode([]);
}
?>