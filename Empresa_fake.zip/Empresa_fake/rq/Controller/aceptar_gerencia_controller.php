<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../Model/conexion.php';

try {
    $sql = "SELECT r.*, 
                   COALESCE(u.nombre_urgencia, 'Normal') AS nombre_urgencia, 
                   COALESCE(p.estado, 'pendiente') AS estado 
            FROM requerimientos r 
            LEFT JOIN urgencia u ON r.id_urgencia_fk = u.id_urgencia 
            LEFT JOIN procesos p ON r.id_requerimiento = p.id_requerimiento_fk 
            WHERE LOWER(p.estado) = 'aceptado' OR LOWER(p.estado) = 'aprobado'
            ORDER BY r.id_requerimiento DESC";
            
    $stmt = $conexion->query($sql);
    $requerimientos = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $requerimientos = [];
}
?>

