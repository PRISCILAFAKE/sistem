<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../Model/conexion.php';
require_once __DIR__ . '/../Helper/mailer_helper.php';

$id_usuario_actual = $_SESSION['id_usuario'] ?? null;
if (!$id_usuario_actual) {
    header("Location: ../View/login_view.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_requerimiento = $_POST['id_requerimiento'] ?? null;
    $accion = $_POST['accion'] ?? null; 

    if ($id_requerimiento && $accion) {
        try {
            $conexion->beginTransaction();

            $sqlCheck = "SELECT COUNT(*) FROM procesos WHERE id_requerimiento_fk = :id_req";
            $stmtCheck = $conexion->prepare($sqlCheck);
            $stmtCheck->execute([':id_req' => $id_requerimiento]);
            $existe = $stmtCheck->fetchColumn();

            if ($accion === 'aceptar') {
                $nuevo_estado = 'pendiente_administracion'; 

                $sqlReq = "UPDATE requerimientos SET estado = :estado, motivo_rechazo = NULL WHERE id_requerimiento = :id_req";
                $stmtReq = $conexion->prepare($sqlReq);
                $stmtReq->execute([
                    ':estado' => $nuevo_estado,
                    ':id_req' => $id_requerimiento
                ]);

                if ($existe > 0) {
                    $sql = "UPDATE procesos SET estado = :estado, motivo_rechazo = NULL, fecha_actualizada = NOW() WHERE id_requerimiento_fk = :id_req";
                    $stmt = $conexion->prepare($sql);
                    $stmt->execute([
                        ':estado' => $nuevo_estado,
                        ':id_req' => $id_requerimiento
                    ]);
                } else {
                    $sql = "INSERT INTO procesos (id_requerimiento_fk, estado, motivo_rechazo, fecha_actualizada) VALUES (:id_req, :estado, NULL, NOW())";
                    $stmt = $conexion->prepare($sql);
                    $stmt->execute([
                        ':id_req' => $id_requerimiento,
                        ':estado' => $nuevo_estado
                    ]);
                }

                $conexion->commit();
                header("Location: ../View/solicitud_ge_view.php?aprobado=1");
                exit();

            } elseif ($accion === 'rechazar') {
                $motivo = trim($_POST['motivo_rechazo'] ?? 'Sin motivo especificado');
                $nuevo_estado = 'rechazado';

                $sqlReq = "UPDATE requerimientos SET estado = :estado, motivo_rechazo = :motivo WHERE id_requerimiento = :id_req";
                $stmtReq = $conexion->prepare($sqlReq);
                $stmtReq->execute([
                    ':estado' => $nuevo_estado,
                    ':motivo' => $motivo,
                    ':id_req' => $id_requerimiento
                ]);

                if ($existe > 0) {
                    $sql = "UPDATE procesos SET estado = :estado, motivo_rechazo = :motivo, fecha_actualizada = NOW() WHERE id_requerimiento_fk = :id_req";
                    $stmt = $conexion->prepare($sql);
                    $stmt->execute([
                        ':estado' => $nuevo_estado,
                        ':motivo' => $motivo,
                        ':id_req' => $id_requerimiento
                    ]);
                } else {
                    $sql = "INSERT INTO procesos (id_requerimiento_fk, estado, motivo_rechazo, fecha_actualizada) VALUES (:id_req, :estado, :motivo, NOW())";
                    $stmt = $conexion->prepare($sql);
                    $stmt->execute([
                        ':id_req' => $id_requerimiento,
                        ':estado' => $nuevo_estado,
                        ':motivo' => $motivo
                    ]);
                }

                $sqlUser = "SELECT u.correo, u.nombre, r.nombre_solicitud 
                            FROM requerimientos r 
                            INNER JOIN usuario u ON r.id_usuario_f = u.id_usuario 
                            WHERE r.id_requerimiento = :id_req";
                $stmtUser = $conexion->prepare($sqlUser);
                $stmtUser->execute([':id_req' => $id_requerimiento]);
                $datosUsuario = $stmtUser->fetch(PDO::FETCH_ASSOC);

                $conexion->commit();

                if ($datosUsuario && !empty($datosUsuario['correo'])) {
                    $asunto = "Requerimiento Rechazado: " . $datosUsuario['nombre_solicitud'];
                    $cuerpo = "Hola <b>" . htmlspecialchars($datosUsuario['nombre']) . "</b>,<br><br>
                               Lamentamos informarle que su requerimiento <b>" . htmlspecialchars($datosUsuario['nombre_solicitud']) . "</b> ha sido <b>rechazado</b> por gerencia.<br><br>
                               <b>Motivo del rechazo:</b><br>
                               <p style='color: red;'>" . nl2br(htmlspecialchars($motivo)) . "</p><br>
                               Puede ingresar al sistema para editar su requerimiento y volver a enviarlo.<br><br>
                               Atentamente,<br>
                               <b>Gerencia</b>";

                    enviarCorreoSistema($datosUsuario['correo'], $datosUsuario['nombre'], $asunto, $cuerpo);
                }

                header("Location: ../View/solicitud_ge_view.php?rechazado=1");
                exit();
            }

        } catch (Exception $e) {
            if ($conexion->inTransaction()) {
                $conexion->rollBack();
            }
            header("Location: ../View/solicitud_ge_view.php?error=" . urlencode($e->getMessage()));
            exit();
        }
    } else {
        header("Location: ../View/solicitud_ge_view.php?error=Datos+incompletos");
        exit();
    }
} else {
    header("Location: ../View/solicitud_ge_view.php");
    exit();
}
?>