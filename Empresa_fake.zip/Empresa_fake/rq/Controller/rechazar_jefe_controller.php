<?php
session_start();
require_once __DIR__ . '/../Model/conexion.php';

if (!isset($_SESSION['id_usuario']) || empty($_SESSION['es_jefe']) || $_SESSION['es_jefe'] != 1) {
    header("Location: ../index.php");
    exit();
}

$id_requerimiento = $_POST['id_requerimiento'] ?? null;

if ($id_requerimiento) {
    try {
        $conexion->beginTransaction();

        $sqlProceso = "DELETE FROM procesos WHERE id_requerimiento_fk = :id";
        $stmtProceso = $conexion->prepare($sqlProceso);
        $stmtProceso->execute([':id' => $id_requerimiento]);

        $sql = "DELETE FROM requerimientos WHERE id_requerimiento = :id";
        $stmt = $conexion->prepare($sql);
        $stmt->execute([':id' => $id_requerimiento]);

        $conexion->commit();
    } catch (PDOException $e) {
        if ($conexion->inTransaction()) {
            $conexion->rollBack();
        }
        die("Error al eliminar/rechazar: " . $e->getMessage());
    }
}

header("Location: ../View/bandeja_jefe_view.php");
exit();
?>