<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../Model/conexion.php';

if (!isset($_SESSION['id_usuario'])) {
    header("Location: ../View/login_view.php");
    exit();
}

$id_usuario = $_SESSION['id_usuario'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['firma']) && $_FILES['firma']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['firma']['tmp_name'];
        $fileName = $_FILES['firma']['name'];
        $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

        $allowedExtensions = ['jpg', 'jpeg', 'png'];

        if (in_array($fileExtension, $allowedExtensions)) {

        $uploadFileDir = '../uploads/firmas/';
            if (!is_dir($uploadFileDir)) {
                mkdir($uploadFileDir, 0755, true);
            }

            $newFileName = 'firma_' . $id_usuario . '_' . time() . '.' . $fileExtension;
            $dest_path = $uploadFileDir . $newFileName;
            $db_path = 'uploads/firmas/' . $newFileName; // Ruta

            if (move_uploaded_file($fileTmpPath, $dest_path)) {
                try {
                    $stmt = $conexion->prepare("UPDATE usuario SET firma = ? WHERE id_usuario = ?");
                    $stmt->execute([$db_path, $id_usuario]);

                    $_SESSION['mensaje'] = "Firma actualizada correctamente.";
                    $_SESSION['tipo_alerta'] = "success";
                } catch (PDOException $e) {
                    $_SESSION['mensaje'] = "Error al actualizar la base de datos: " . $e->getMessage();
                    $_SESSION['tipo_alerta'] = "danger";
                }
            } else {
                $_SESSION['mensaje'] = "Error al mover el archivo al servidor.";
                $_SESSION['tipo_alerta'] = "danger";
            }
        } else {
            $_SESSION['mensaje'] = "Formato de imagen no permitido. Solo se aceptan JPG y PNG.";
            $_SESSION['tipo_alerta'] = "warning";
        }
    }
    
    header("Location: perfil_controller.php");
    exit();
}

try {
    $stmt = $conexion->prepare("
        SELECT u.*, a.nombre_area 
        FROM usuario u 
        LEFT JOIN areas a ON u.id_area_fk = a.id_area 
        WHERE u.id_usuario = ?
    ");
    $stmt->execute([$id_usuario]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$usuario) {
        echo "Usuario no encontrado.";
        exit();
    }
} catch (PDOException $e) {
    echo "Error en la consulta: " . $e->getMessage();
    exit();
}

require_once __DIR__ . '/../View/perfil_view.php';