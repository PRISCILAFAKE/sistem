<?php
session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nueva Cuenta - Thunderbird</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-light">

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
        <div class="container-fluid px-4">
            <span class="navbar-brand fw-bold">T-Soluciona - Panel de Administración</span>
            <div class="ms-auto">
                <a href="thunderbird_cuentas.php" class="btn btn-outline-light btn-sm"><i class="fas fa-arrow-left"></i> Volver</a>
            </div>
        </div>
    </nav>

    <div class="container" style="max-width: 650px;">
        <div class="card shadow-sm border-0">
            <div class="card-body p-4">
                <h3 class="fw-bold mb-3"><i class="fas fa-user-plus text-success"></i> Añadir Nueva Cuenta de Thunderbird</h3>
                <hr class="mb-4">

                <form action="../Controllers/guardar_cuenta_thunderbird.php" method="POST">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Nombres:</label>
                        <input type="text" class="form-control" name="nombres" placeholder="Ingrese nombres completos" autocomplete="off" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Correo Corporativo:</label>
                        <input type="email" class="form-control" name="correoCorporativo" placeholder="correo@t-soluciona.com" autocomplete="off" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Contraseña:</label>
                        <input type="text" class="form-control" name="contrasena" placeholder="Contraseña de la cuenta" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Empresa:</label>
                        <select class="form-select" name="empresa" required>
                            <option value="">Seleccione una empresa...</option>
                            <option value="PERU INTERMEDIACION LABORAL S.A.C">PERU INTERMEDIACION LABORAL S.A.C</option>
                            <option value="T-SOLUCIONA S.A.C.">T-SOLUCIONA S.A.C.</option>
                            <option value="GRUPO T-SOLUCIONA PERU E.I.R.L.">GRUPO T-SOLUCIONA PERU E.I.R.L.</option>
                            <option value="X-TERNA E.I.R.L.">X-TERNA E.I.R.L.</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Estado:</label>
                        <select class="form-select" name="estado" required>
                            <option value="activo" selected>Activo</option>
                            <option value="inactivo">Inactivo</option>
                        </select>
                    </div>

                    <div class="d-flex justify-content-end gap-2 mt-4">
                        <a href="thunderbird_cuentas.php" class="btn btn-secondary">Cancelar</a>
                        <button type="submit" class="btn btn-success"><i class="fas fa-save"></i> Guardar Cuenta</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>