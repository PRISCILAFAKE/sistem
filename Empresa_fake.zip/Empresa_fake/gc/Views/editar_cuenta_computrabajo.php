<?php
session_start();
require_once __DIR__ . '/../Config/conexion.php';

if (!isset($_GET['id'])) {
    header("Location: computrabajo_cuentas.php");
    exit();
}

$id = intval($_GET['id']);

$sql = "SELECT * FROM gc_computrabajo_cuentas WHERE id = :id";
$stmt = $conexion->prepare($sql);
$stmt->execute([':id' => $id]);
$cuenta = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$cuenta) {
    header("Location: computrabajo_cuentas.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Cuenta - Computrabajo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-light">

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
        <div class="container-fluid px-4">
            <span class="navbar-brand fw-bold">T-Soluciona - Panel de Administración</span>
            <div class="ms-auto">
                <a href="computrabajo_cuentas.php" class="btn btn-outline-light btn-sm"><i class="fas fa-arrow-left"></i> Volver</a>
            </div>
        </div>
    </nav>

    <div class="container" style="max-width: 600px;">
        <div class="card shadow-sm border-0">
            <div class="card-body p-4">
                <h3 class="fw-bold mb-3"><i class="fas fa-edit text-warning"></i> Editar Cuenta de Computrabajo</h3>
                <hr class="mb-4">

                <form action="../Controllers/actualizar_cuenta_computrabajo.php" method="POST">
                    <input type="hidden" name="id" value="<?php echo $cuenta['id']; ?>">

                    <div class="mb-3">
                        <label class="form-label fw-bold">Nombres y Apellidos:</label>
                        <input type="text" class="form-control" name="nombres" value="<?php echo htmlspecialchars($cuenta['nombres']); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Correo Corporativo:</label>
                        <input type="email" class="form-control" name="correoCorporativo" value="<?php echo htmlspecialchars($cuenta['correoCorporativo']); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Contraseña:</label>
                        <input type="text" class="form-control" name="contrasena" value="<?php echo htmlspecialchars($cuenta['contrasenia']); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Empresa:</label>
                        <select class="form-select" name="empresa" required>
                            <option value="PERU INTERMEDIACION LABORAL S.A.C" <?php echo ($cuenta['empresa'] == 'PERU INTERMEDIACION LABORAL S.A.C') ? 'selected' : ''; ?>>PERU INTERMEDIACION LABORAL S.A.C</option>
                            <option value="T-SOLUCIONA S.A.C." <?php echo ($cuenta['empresa'] == 'T-SOLUCIONA S.A.C.') ? 'selected' : ''; ?>>T-SOLUCIONA S.A.C.</option>
                            <option value="GRUPO T-SOLUCIONA PERU E.I.R.L." <?php echo ($cuenta['empresa'] == 'GRUPO T-SOLUCIONA PERU E.I.R.L.') ? 'selected' : ''; ?>>GRUPO T-SOLUCIONA PERU E.I.R.L.</option>
                            <option value="X-TERNA E.I.R.L." <?php echo ($cuenta['empresa'] == 'X-TERNA E.I.R.L.') ? 'selected' : ''; ?>>X-TERNA E.I.R.L.</option>
                        </select>
                    </div>

                    <div class="d-flex justify-content-end gap-2 mt-4">
                        <a href="computrabajo_cuentas.php" class="btn btn-secondary">Cancelar</a>
                        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Guardar Cambios</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>