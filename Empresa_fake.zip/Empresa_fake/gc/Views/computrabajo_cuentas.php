<?php
session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cuentas de Computrabajo</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-light">


    <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
        <div class="container-fluid px-4">
            <span class="navbar-brand fw-bold">T-Soluciona - Panel de Administración</span>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto align-items-center gap-3">
                    <li class="nav-item">
                        <a href="index.php" class="nav-link text-white px-0">Inicio</a>
                    </li>
                    
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle text-white px-0" href="#" id="modulesDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Modulos
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end shadow">
                            <li><a class="dropdown-item" href="computrabajo_cuentas.php"><i class="fas fa-briefcase text-warning me-2"></i> Cuentas de Computrabajo</a></li>
                            <li><a class="dropdown-item" href="drive_cuentas.php"><i class="fab fa-google-drive text-success me-2"></i> Cuentas de Drive</a></li>
                            <li><a class="dropdown-item" href="windows_cuentas.php"><i class="fab fa-windows text-primary me-2"></i> Cuentas de Windows</a></li>
                            <li><a class="dropdown-item" href="thunderbird_cuentas.php"><i class="fas fa-envelope text-info me-2"></i> Cuentas de Thunderbird</a></li>
                        </ul>
                    </li>

                    <li class="nav-item">
                        <a href="../Controllers/cerrar_sesion.php" class="btn btn-danger btn-sm">Cerrar Sesión</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container-fluid px-4">

        <div class="row align-items-center mb-3">
            <div class="col-md-8">
                <h2 class="fw-bold mb-0">Cuentas de Computrabajo</h2>
                <p class="text-muted mb-0">Gestión y seguimiento de las Cuentas</p>
            </div>
            <div class="col-md-4 text-end">

                <a href="exportar_computrabajo.php" id="btnExportar" class="btn btn-success">
                    <i class="fas fa-file-excel me-1"></i> Exportar a Excel
                </a>
            </div>
        </div>

            <div class="card shadow-sm border-0 mb-4 p-3 bg-white">

        <div class="row mb-3 align-items-center">
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-text bg-white"><i class="fas fa-search text-muted"></i></span>
                    <input type="text" id="inputBusqueda" class="form-control" placeholder="Buscar por nombres, correo o empresa..." autocomplete="off">
                </div>
            </div>
            <div class="col-md-7 text-end">
                <a href="nueva_cuenta_computrabajo.php" class="btn btn-secondary">
                    <i class="fas fa-user-plus me-1"></i> Añadir Nueva Cuenta
                </a>
            </div>
        </div>
</div>

            <div class="card shadow-sm border-0 mb-4 p-3 bg-white">


        <div class="card shadow-sm border-0 mb-4">
            <div class="card-body p-0">
                <div class="table-responsive" style="max-height: 600px;  max-width: 1900px; overflow-y: auto;">
                    <table class="table table-striped table-hover align-middle mb-0">
                        <thead class="table-dark">
                            <tr>
                                <th style="position: sticky; top: 0; background-color: #212529; z-index: 10;">ID</th>
                                <th style="position: sticky; top: 0; background-color: #212529; z-index: 10;">Nombres</th>
                                <th style="position: sticky; top: 0; background-color: #212529; z-index: 10;">Correo Corporativo</th>
                                <th style="position: sticky; top: 0; background-color: #212529; z-index: 10;">Contraseña</th>
                                <th style="position: sticky; top: 0; background-color: #212529; z-index: 10;">Empresa</th>
                                <th style="position: sticky; top: 0; background-color: #212529; z-index: 10;">Estado</th>
                                <th style="position: sticky; top: 0; background-color: #212529; z-index: 10;" class="text-center">Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="tablaResultados">

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    </div>



    <script>
    document.addEventListener("DOMContentLoaded", function() {
        const inputBusqueda = document.getElementById("inputBusqueda");
        const tablaResultados = document.getElementById("tablaResultados");
        const btnExportar = document.getElementById("btnExportar");

        function realizarBusqueda(termino = "") {

        fetch("../Controllers/ComputrabajoController.php?termino=" + encodeURIComponent(termino))
                .then(response => response.text())
                .then(html => {
                    tablaResultados.innerHTML = html;
                })
                .catch(error => console.error("Error al buscar:", error));

            btnExportar.href = "exportar_computrabajo.php?termino=" + encodeURIComponent(termino);
        }

        realizarBusqueda();

        inputBusqueda.addEventListener("keyup", function() {
            realizarBusqueda(this.value);
        });
    });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>