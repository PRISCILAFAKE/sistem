<?php
require_once __DIR__ . '/../Config/conexion.php';

// Recoger el término de búsqueda si existe
$termino = isset($_GET['termino']) ? trim($_GET['termino']) : '';

// Definir el nombre del archivo con extensión .xls
$filename = "Cuentas_Drive_" . date('Y-m-d') . ".xls";

// Forzar las cabeceras para que Excel lo interprete como una hoja de cálculo nativa
header("Content-Type: application/vnd.ms-excel; charset=UTF-8");
header("Content-Disposition: attachment; filename=\"$filename\"");
header("Pragma: no-cache");
header("Expires: 0");

try {
    // Consultar según si hay filtro activo o no
    if ($termino !== '') {
        $sql = "SELECT id, nombres, correoCorporativo, contrasenia, empresa, estado 
                FROM gc_drive_cuentas 
                WHERE nombres LIKE :ter 
                OR correoCorporativo LIKE :ter 
                OR empresa LIKE :ter 
                ORDER BY id DESC";
        $stmt = $conexion->prepare($sql);
        $stmt->execute([':ter' => "%$termino%"]);
    } else {
        $sql = "SELECT id, nombres, correoCorporativo, contrasenia, empresa, estado 
                FROM gc_drive_cuentas 
                ORDER BY id DESC";
        $stmt = $conexion->prepare($sql);
        $stmt->execute();
    }

    $cuentas = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<table border="1">
    <thead>
        <tr style="background-color: #212529; color: #ffffff; font-weight: bold;">
            <th>ID</th>
            <th>Nombres</th>
            <th>Correo Corporativo</th>
            <th>Contraseña</th>
            <th>Empresa</th>
            <th>Estado</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($cuentas as $row): ?>
        <tr>
            <!-- Usamos mso-number-format:@ para asegurar que los textos largos o números no se extrañen -->
            <td style="mso-number-format:'@';"><?php echo $row['id']; ?></td>
            <td><?php echo htmlspecialchars($row['nombres'], ENT_QUOTES, 'UTF-8'); ?></td>
            <td><?php echo htmlspecialchars($row['correoCorporativo'], ENT_QUOTES, 'UTF-8'); ?></td>
            <td><?php echo htmlspecialchars($row['contrasenia'], ENT_QUOTES, 'UTF-8'); ?></td>
            <td><?php echo htmlspecialchars($row['empresa'], ENT_QUOTES, 'UTF-8'); ?></td>
            <td><?php echo htmlspecialchars($row['estado'], ENT_QUOTES, 'UTF-8'); ?></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<?php
} catch (PDOException $e) {
    echo "Error al exportar: " . $e->getMessage();
}
exit();
?>