<?php
session_start();
require_once __DIR__ . '/../Config/conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id']);
    $nombres = trim($_POST['nombres']);
    $correoCorporativo = trim($_POST['correoCorporativo']);
    $contrasena = trim($_POST['contrasena']);
    $empresa = trim($_POST['empresa']);

    try {
        $sql = "UPDATE gc_drive_cuentas 
                SET nombres = :nombres, correoCorporativo = :correo, contrasenia = :contrasena, empresa = :empresa 
                WHERE id = :id";
                
        $stmt = $conexion->prepare($sql);
        $stmt->execute([
            ':nombres' => $nombres,
            ':correo' => $correoCorporativo,
            ':contrasena' => $contrasena,
            ':empresa' => $empresa,
            ':id' => $id
        ]);

        header("Location: ../Views/drive_cuentas.php?actualizado=1");
        exit();

    } catch (PDOException $e) {
        echo "Error al actualizar: " . htmlspecialchars($e->getMessage());
    }
} else {
    header("Location: ../Views/drive_cuentas.php");
    exit();
}
?>