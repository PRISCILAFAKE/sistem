<?php
session_start();
require_once __DIR__ . '/../Config/conexion.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    try {
        $sql = "DELETE FROM gc_thunderbird_cuentas WHERE id = :id";
        $stmt = $conexion->prepare($sql);
        $stmt->execute([':id' => $id]);

        header("Location: ../Views/thunderbird_cuentas.php?eliminado=1");
        exit();

    } catch (PDOException $e) {
        echo "Error al eliminar el registro: " . htmlspecialchars($e->getMessage());
    }
} else {
    header("Location: ../Views/thunderbird_cuentas.php");
    exit();
}
?>