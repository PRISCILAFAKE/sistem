<?php
session_start();
require_once __DIR__ . '/../Config/conexion.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    try {
        // Sentencia SQL inteligente que invierte el estado actual por sí sola
        $sql = "UPDATE gc_drive_cuentas 
                SET estado = CASE 
                    WHEN estado = 'activo' THEN 'inactivo' 
                    ELSE 'activo' 
                END 
                WHERE id = :id";
                
        $stmt = $conexion->prepare($sql);
        $stmt->execute([':id' => $id]);

        header("Location: ../Views/drive_cuentas.php?estado_actualizado=1");
        exit();

    } catch (PDOException $e) {
        echo "Error al cambiar el estado: " . htmlspecialchars($e->getMessage());
    }
} else {
    header("Location: ../Views/drive_cuentas.php");
    exit();
}
?>