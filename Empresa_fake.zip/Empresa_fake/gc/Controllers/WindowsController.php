<?php
require_once __DIR__ . '/../Config/conexion.php';

$termino = isset($_GET['termino']) ? trim($_GET['termino']) : '';

try {
    $sql = "SELECT id, nombre_colaborador, usuario, contrasena, empresa, estado, fecha_creacion 
            FROM gc_cuentas_windows 
            WHERE nombre_colaborador LIKE :ter 
            OR usuario LIKE :ter 
            OR empresa LIKE :ter 
            ORDER BY id DESC";

    $stmt = $conexion->prepare($sql);
    $stmt->execute([':ter' => "%$termino%"]);
    $cuentas = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (count($cuentas) > 0) {
        foreach ($cuentas as $row) {
            $badgeColor = ($row['estado'] === 'activo') ? 'bg-success' : 'bg-secondary';
            $btnEstadoColor = ($row['estado'] === 'activo') ? 'btn-outline-secondary' : 'btn-outline-success';
            $btnEstadoIcon = ($row['estado'] === 'activo') ? 'fa-toggle-on' : 'fa-toggle-off';
            $btnEstadoTitle = ($row['estado'] === 'activo') ? 'Desactivar cuenta' : 'Activar cuenta';

            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['id']) . "</td>";
            echo "<td>" . htmlspecialchars($row['nombre_colaborador']) . "</td>";
            echo "<td>" . htmlspecialchars($row['usuario']) . "</td>";
            echo "<td>" . htmlspecialchars($row['contrasena']) . "</td>";
            echo "<td>" . htmlspecialchars($row['empresa']) . "</td>";
            echo "<td><span class='badge {$badgeColor}'>" . htmlspecialchars($row['estado']) . "</span></td>";
            echo "<td>" . htmlspecialchars($row['fecha_creacion']) . "</td>";

            echo "<td class='text-center'>
                    <a href='editar_cuenta_windows.php?id=" . $row['id'] . "' class='btn btn-sm btn-warning' title='Editar'><i class='fas fa-edit'></i></a>
                    <a href='../Controllers/cambiar_estado_windows.php?id=" . $row['id'] . "' class='btn btn-sm {$btnEstadoColor}' title='{$btnEstadoTitle}' onclick='return confirm(\"¿Deseas cambiar el estado de esta cuenta?\")'><i class='fas {$btnEstadoIcon}'></i></a>
                  </td>";
            echo "</tr>";

        }
    } else {
        echo "<tr><td colspan='6' class='text-center text-muted py-4'>No se encontraron registros coincidentes.</td></tr>";
    }

} catch (PDOException $e) {
    echo "<tr><td colspan='6' class='text-center text-danger py-4'>Error en la consulta: " . htmlspecialchars($e->getMessage()) . "</td></tr>";
}
?>