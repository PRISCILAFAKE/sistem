<?php
session_start();
require_once __DIR__ . '/../Config/conexion.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    try {
        $sql = "UPDATE gc_cuentas_windows 
                SET estado = CASE 
                    WHEN estado = 'activo' THEN 'inactivo' 
                    ELSE 'activo' 
                END 
                WHERE id = :id";
                
        $stmt = $conexion->prepare($sql);
        $stmt->execute([':id' => $id]);

        header("Location: ../Views/windows_cuentas.php?estado_actualizado=1");
        exit();

    } catch (PDOException $e) {
        echo "Error al cambiar el estado: " . htmlspecialchars($e->getMessage());
    }
} else {
    header("Location: ../Views/windows_cuentas.php");
    exit();
}
?>