<?php
session_start();
require_once __DIR__ . '/../Config/conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombres = trim($_POST['nombres']);
    $correoCorporativo = trim($_POST['correoCorporativo']);
    $contrasena = trim($_POST['contrasena']);
    $empresa = trim($_POST['empresa']);
    $estado = trim($_POST['estado']);

    try {
        $sql = "INSERT INTO gc_thunderbird_cuentas (nombres, correoCorporativo, contrasena, empresa, estado) 
                VALUES (:nombres, :correo, :contrasena, :empresa, :estado)";
                
        $stmt = $conexion->prepare($sql);
        $stmt->execute([
            ':nombres' => $nombres,
            ':correo' => $correoCorporativo,
            ':contrasena' => $contrasena,
            ':empresa' => $empresa,
            ':estado' => $estado
        ]);

        header("Location: ../Views/thunderbird_cuentas.php?creado=1");
        exit();

    } catch (PDOException $e) {
        echo "Error al guardar el registro: " . htmlspecialchars($e->getMessage());
    }
} else {
    header("Location: ../Views/thunderbird_cuentas.php");
    exit();
}
?>