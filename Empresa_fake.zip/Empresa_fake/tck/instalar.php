<?php
require_once 'config/database.php';

echo "<h2>🛠️ Configurando Base de Datos...</h2>";

$conn = getConnection();

// 1. Crear tabla de tickets
$table_tickets = "CREATE TABLE IF NOT EXISTS tck_tickets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre_solicitante VARCHAR(100) NOT NULL,
    celular VARCHAR(20) NOT NULL,
    email VARCHAR(100),
    descripcion TEXT NOT NULL,
    prioridad ENUM('Baja', 'Media', 'Alta') DEFAULT 'Baja',
    estado ENUM('Nuevo', 'En Progreso', 'Resuelto', 'Cerrado') DEFAULT 'Nuevo',
    creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    actualizado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

if ($conn->query($table_tickets)) {
    echo "✅ Tabla 'tickets' lista.<br>";
} else {
    echo "❌ Error en tabla 'tickets': " . $conn->error . "<br>";
}

// 2. Crear tabla de administradores
$table_admins = "CREATE TABLE IF NOT EXISTS tck_administradores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    nombre VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

if ($conn->query($table_admins)) {
    echo "✅ Tabla 'administradores' lista.<br>";
} else {
    echo "❌ Error en tabla 'administradores': " . $conn->error . "<br>";
}

// 3. Insertar Admin por defecto
$check = $conn->query("SELECT id FROM tck_administradores WHERE usuario = 'admin'");
if ($check->num_rows === 0) {
    $sql_admin = "INSERT INTO tck_administradores (usuario, password, nombre) VALUES ('admin', 'admin123', 'Admin Sistema')";
    if ($conn->query($sql_admin)) {
        echo "👤 Usuario administrador creado (admin / admin123).<br>";
    }
} else {
    echo "ℹ️ El usuario administrador ya existe.<br>";
}

echo "<br>🚀 **¡Todo listo!** Ya puedes ir a <a href='index.php'>Inicio</a>.";
?>
