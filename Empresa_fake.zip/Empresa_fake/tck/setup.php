<?php
/**
 * SETUP AUTOMÁTICO - CREAR BASE DE DATOS
 * 
 * Accede a: http://localhost/tickets_sistema/setup.php
 * Esto creará la base de datos y tablas automáticamente
 */

// Conexión inicial sin seleccionar BD
$conn = new mysqli('localhost', 'root', '');

if ($conn->connect_error) {
    die('Error de conexión a MySQL: ' . $conn->connect_error);
}

// Crear base de datos
$sql_db = "CREATE DATABASE IF NOT EXISTS tickets_db";
if ($conn->query($sql_db)) {
    echo "✓ Base de datos 'tickets_db' creada o ya existe.<br>";
} else {
    die('Error creando BD: ' . $conn->error);
}

// Seleccionar BD
$conn->select_db('tickets_db');

// Crear tabla de tickets
$sql_tickets = "CREATE TABLE IF NOT EXISTS tck_tickets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre_solicitante VARCHAR(100) NOT NULL,
    celular VARCHAR(20) NOT NULL,
    email VARCHAR(100),
    descripcion TEXT NOT NULL,
    prioridad ENUM('Baja', 'Media', 'Alta') DEFAULT 'Baja',
    estado ENUM('Nuevo', 'En Progreso', 'Resuelto', 'Cerrado') DEFAULT 'Nuevo',
    creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    actualizado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_estado (estado),
    INDEX idx_prioridad (prioridad)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if ($conn->query($sql_tickets)) {
    echo "✓ Tabla 'tickets' creada o ya existe.<br>";
} else {
    die('Error creando tabla tickets: ' . $conn->error);
}

// Crear tabla de historial
$sql_history = "CREATE TABLE IF NOT EXISTS tck_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ticket_id INT NOT NULL,
    accion VARCHAR(255),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
    INDEX idx_ticket_id (ticket_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if ($conn->query($sql_history)) {
    echo "✓ Tabla 'ticket_history' creada o ya existe.<br>";
} else {
    die('Error creando tabla ticket_history: ' . $conn->error);
}

$conn->close();

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Setup - Sistema de Tickets</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .container {
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            max-width: 600px;
            text-align: center;
        }
        
        h1 {
            color: #333;
            margin-bottom: 10px;
            font-size: 2em;
        }
        
        h2 {
            color: #667eea;
            margin-top: 30px;
            margin-bottom: 20px;
            font-size: 1.3em;
        }
        
        .success-box {
            background: #d4edda;
            color: #155724;
            padding: 20px;
            border-radius: 5px;
            border: 1px solid #c3e6cb;
            margin-bottom: 20px;
        }
        
        .info-box {
            background: #d1ecf1;
            color: #0c5460;
            padding: 20px;
            border-radius: 5px;
            border: 1px solid #bee5eb;
            margin-bottom: 20px;
            text-align: left;
        }
        
        .info-box p {
            margin: 10px 0;
        }
        
        .info-box strong {
            color: #0c5460;
        }
        
        .next-steps {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 5px;
            text-align: left;
            margin-top: 20px;
        }
        
        .next-steps ol {
            margin: 10px 0;
            padding-left: 20px;
        }
        
        .next-steps li {
            margin: 10px 0;
            color: #333;
        }
        
        .button {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 5px;
            font-size: 1em;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin-top: 20px;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        
        .button:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>✓ Setup Completado</h1>
        
        <div class="success-box">
            <h2>¡Base de datos creada exitosamente!</h2>
        </div>

        <div class="info-box">
            <p><strong>Base de datos:</strong> tickets_db</p>
            <p><strong>Tablas:</strong></p>
            <ul">
                <li>✓ tickets</li>
                <li>✓ ticket_history</li>
            </ul>
        </div>

        <div class="next-steps">
            <h3 style="margin-top: 0; color: #333;">⚠️ PASO IMPORTANTE: Configurar Email</h3>
            <p>Cuando ejecutes el sistema y se cree un ticket, necesitas configurar dónde enviar los emails.</p>
            
            <ol>
                <li>Ve a <code>config/database.php</code> (líneas 30-34)</li>
                <li>Reemplaza estos valores:
                    <ul style="margin-left: 20px; margin-top: 10px;">
                        <li><code>ADMIN_EMAIL</code> = Tu correo donde recibirás notificaciones</li>
                        <li><code>ADMIN_NAME</code> = Nombre de tu equipo o admin</li>
                    </ul>
                </li>
                <li>Para <strong>testing rápido</strong> (sin configurar SMTP):
                    <ul style="margin-left: 20px; margin-top: 10px;">
                        <li>Usa Mailtrap.io (gratis)</li>
                        <li>O configura mail() de PHP en XAMPP</li>
                    </ul>
                </li>
            </ol>
        </div>

        <a href="index.php" class="button">→ Ir al Sistema de Tickets</a>
    </div>
</body>
</html>
