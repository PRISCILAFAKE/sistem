# 🎟️ Sistema de Gestión de Tickets - Guía de Inicio

## ⚡ Inicio Rápido (3 pasos)

### Paso 1: Crear Base de Datos
1. Abre en tu navegador: **http://localhost/tickets_sistema/setup.php**
2. Verás un mensaje: "✓ Setup Completado"
3. La BD `tickets_db` se creará automáticamente

### Paso 2: Configurar Email (IMPORTANTE)
Edita el archivo `config/database.php` y busca estas líneas:

```php
define('ADMIN_EMAIL', ''); // Tu email aquí
define('ADMIN_NAME', 'Admin Soporte TI');
```

**Reemplaza con:**
```php
define('ADMIN_EMAIL', 'tu_email@gmail.com'); // O el email donde quieras recibir notificaciones
define('ADMIN_NAME', 'Soporte TI - Empresa');
```

### Paso 3: Usar el Sistema
1. Abre en tu navegador: **http://localhost/tickets_sistema**
2. ¡Listo! Ya puedes crear y gestionar tickets

---

## 🔧 Configuración de Email

### Opción A: Mailtrap (Testing - Recomendado HOY)
1. Ve a https://mailtrap.io/
2. Regístrate gratis
3. En Dashboard → Email Testing → SMTP
4. Copia credenciales SMTP
5. En `config/database.php`, reemplaza:

```php
define('MAILTRAP_HOST', 'live.smtp.mailtrap.io');
define('MAILTRAP_PORT', 465);
define('MAILTRAP_USER', 'tu_usuario_mailtrap');  // De Mailtrap
define('MAILTRAP_PASS', 'tu_password_mailtrap'); // De Mailtrap
define('ADMIN_EMAIL', 'tu_email@gmail.com');      // Tu email real
```

### Opción B: Gmail + XAMPP (Configuración Local)
1. Habilita "Aplicaciones de menor seguridad" en tu cuenta Google
2. Edita `config/database.php`:

```php
define('MAILTRAP_HOST', 'smtp.gmail.com');
define('MAILTRAP_PORT', 465);
define('MAILTRAP_USER', 'tu_email@gmail.com');
define('MAILTRAP_PASS', 'tu_contraseña_app');
define('ADMIN_EMAIL', 'tu_email@gmail.com');
```

### Opción C: Sin Email (Testing Básico)
- Por ahora, los emails NO se enviarán, pero el ticket se creará correctamente
- Los datos se guardarán en la BD igual
- Configura email cuando quieras

---

## 📋 Estructura de Carpetas

```
tickets_sistema/
├── index.php           ← Acceso principal
├── setup.php           ← Setup automático de BD (usar una sola vez)
├── script.js           ← Lógica JavaScript (AJAX)
├── config/
│   └── database.php    ← Configuración (EDITAR AQUÍ)
├── api/
│   ├── create_ticket.php      ← Crear ticket
│   ├── get_tickets.php        ← Listar tickets
│   └── update_status.php      ← Cambiar estado
└── mail/
    └── send_notification.php  ← Enviar email
```

---

## 🎯 Flujo del Sistema

### Para Trabajadores:
1. **Llenan formulario** con: Nombre, Celular*, Email, Problema, Urgencia
2. **Crean ticket** → Reciben número de ticket (Ej: #0001)
3. **Guardan número** para futuras consultas
4. **Ven en tabla** el estado de su ticket

### Para Admin (Tú):
1. **Recibes email** cuando se crea un ticket
2. **Buscas el # en la plataforma** → Ves detalles + contacto del trabajador
3. **Llamas al trabajador** por celular (número en el email)
4. **Cambias estado** en la plataforma:
   - Nuevo → En Progreso (cuando empiezas)
   - En Progreso → Resuelto (cuando lo solucionas)
   - Resuelto → Cerrado (cuando confirmas)

---

## 🧪 Prueba Veloz

1. Abre http://localhost/tickets_sistema
2. Completa el formulario (usa tu celular)
3. Dale en "Crear Ticket"
4. Deberías ver: "✓ Ticket #0001 creado exitosamente"
5. En tabla abajo, aparecerá el ticket con estado "Nuevo"
6. Haz clic en "Ver Detalles"
7. Cambia estado a "En Progreso" y guarda

✓ **Si todo funciona → El sistema está listo para producción**

---

## 🆘 Solución de Problemas

### "Error de conexión a base de datos"
- ✓ Entra a http://localhost/setup.php nuevamente
- ✓ Verifica que MySQL esté corriendo (XAMPP)

### "La tabla está vacía"
- ✓ Crea un ticket nuevo desde el formulario
- ✓ Actualiza la página (F5)

### "No recibo emails"
- ✓ Entra a Mailtrap.io y verifica que llegaron (sección "Inbox")
- ✓ Verifica que ADMIN_EMAIL esté correcto en config/database.php

### "El formulario no envía"
- ✓ Abre consola (F12) → pestaña "Console"
- ✓ Verifica que no haya errores JavaScript

---

## 📊 Estados de Ticket

| Estado | Descripción |
|--------|------------|
| **Nuevo** | Acaba de crearse, sin revisar |
| **En Progreso** | Estás trabajando en ello |
| **Resuelto** | Listo, esperando confirmación |
| **Cerrado** | Problema totalmente solucionado |

---

## 📞 Soporte

Si hay problemas:
1. Verifica la consola del navegador (F12)
2. Revisa los logs de PHP en XAMPP
3. Intenta nuevamente el setup.php

---

**¡Sistema listo en menos de 1 hora! 🚀**
