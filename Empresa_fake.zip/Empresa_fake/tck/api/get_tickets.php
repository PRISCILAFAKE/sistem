<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../config/database.php';

$estado = $_GET['estado'] ?? '';
$prioridad = $_GET['prioridad'] ?? '';

$conn = getConnection();
$sql = "SELECT id, nombre_solicitante, celular, email, descripcion, prioridad, estado, creado_en FROM tck_tickets WHERE 1=1";
$params = [];
$types = "";

if ($estado) {
    $sql .= " AND estado = ?";
    $params[] = $estado;
    $types .= "s";
}
if ($prioridad) {
    $sql .= " AND prioridad = ?";
    $params[] = $prioridad;
    $types .= "s";
}

$sql .= " ORDER BY creado_en DESC";
$stmt = $conn->prepare($sql);

if ($types) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();
$tickets = [];

$estados_posibles = ['Nuevo', 'En Progreso', 'Resuelto', 'Cerrado'];
$orden_estados = array_flip($estados_posibles);

while ($row = $result->fetch_assoc()) {
    $ticket_id = $row['id'];
    $estado_actual = $row['estado'];
    $idx_actual = $orden_estados[$estado_actual] ?? 0;
    
    // Obtener imágenes
    $img_sql = "SELECT imagen, imagen_tipo FROM tck_imagenes WHERE ticket_id = ?";
    $img_stmt = $conn->prepare($img_sql);
    $img_stmt->bind_param("i", $ticket_id);
    $img_stmt->execute();
    $img_res = $img_stmt->get_result();
    
    $imagenes = [];
    while ($img_row = $img_res->fetch_assoc()) {
        $imagenes[] = [
            'url' => 'data:' . $img_row['imagen_tipo'] . ';base64,' . base64_encode($img_row['imagen'])
        ];
    }
    $img_stmt->close();

    $timeline_html = '<div class="timeline-steps">';
    
    foreach ($estados_posibles as $index => $est) {
        $step_num = $index + 1;
        $idx_est = $orden_estados[$est];
        
        $clase = '';
        $disabled_attr = '';

        if ($est === $estado_actual) {
            $clase = 'active';
        } elseif ($idx_est < $idx_actual) {
            $clase = 'completed disabled-step'; // Ya pasó, bloqueado
            $disabled_attr = 'disabled style="cursor: not-allowed; opacity: 0.7;"';
        } else {
            // Futuros (permitidos para avanzar)
            $clase = 'pending';
        }

        $timeline_html .= '<button type="button" class="timeline-step ' . $clase . '" data-id="' . $ticket_id . '" data-estado="' . $est . '" data-actual="' . $estado_actual . '" ' . $disabled_attr . '>';
        $timeline_html .= '<div class="circle">' . ($idx_est < $idx_actual ? '✓' : $step_num) . '</div>';
        $timeline_html .= '<span class="label">' . $est . '</span>';
        $timeline_html .= '</button>';
    }
    $timeline_html .= '</div>';

    $tickets[] = [
        'id' => $row['id'],
        'numero' => str_pad($row['id'], 4, '0', STR_PAD_LEFT),
        'nombre_solicitante' => $row['nombre_solicitante'],
        'celular' => $row['celular'],
        'email' => $row['email'],
        'descripcion' => $row['descripcion'],
        'prioridad' => $row['prioridad'],
        'estado' => $estado_actual,
        'estado_html' => $timeline_html,
        'creado_en' => date('d/m/Y', strtotime($row['creado_en'])),
        'imagenes' => $imagenes
    ];
}

echo json_encode(['success' => true, 'tickets' => $tickets]);
$stmt->close();
?>