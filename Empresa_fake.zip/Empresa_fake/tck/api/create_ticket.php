<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Método no permitido']);
    exit;
}

$nombre = $_POST['nombre'] ?? '';
$celular = $_POST['celular'] ?? '';
$email = $_POST['email'] ?? '';
$descripcion = $_POST['descripcion'] ?? '';
$prioridad = $_POST['prioridad'] ?? 'Baja';

if (empty($nombre) || empty($celular) || empty($descripcion)) {
    echo json_encode(['success' => false, 'message' => 'Faltan campos requeridos']);
    exit;
}

$conn = getConnection();
$conn->begin_transaction();

try {
    // 1. Insertar el ticket
    $sql = "INSERT INTO tck_tickets (nombre_solicitante, celular, email, descripcion, prioridad) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $nombre, $celular, $email, $descripcion, $prioridad);
    $stmt->execute();
    $ticket_id = $conn->insert_id;
    $stmt->close();

    // 2. Procesar Múltiples Imágenes
    if (isset($_FILES['imagen'])) {
        $files = $_FILES['imagen'];
        $count = count($files['name']);

        for ($i = 0; $i < $count; $i++) {
            if ($files['error'][$i] === UPLOAD_ERR_OK) {
                $check = getimagesize($files['tmp_name'][$i]);
                if ($check !== false) {
                    $img_data = file_get_contents($files['tmp_name'][$i]);
                    $img_tipo = $files['type'][$i];

                    $sql_img = "INSERT INTO tck_imagenes (ticket_id, imagen, imagen_tipo) VALUES (?, ?, ?)";
                    $stmt_img = $conn->prepare($sql_img);
                    $null = NULL;
                    $stmt_img->bind_param("ibs", $ticket_id, $null, $img_tipo);
                    $stmt_img->send_long_data(1, $img_data);
                    $stmt_img->execute();
                    $stmt_img->close();
                }
            }
        }
    }

    $conn->commit();

    // 3. Enviar Notificación por Email
    require_once __DIR__ . '/../mail/send_notification.php';
    $notificacion = sendNotification($ticket_id, $nombre, $celular, $email, $descripcion, $prioridad);

    echo json_encode([
        'success' => true, 
        'message' => 'Ticket creado con éxito', 
        'ticket_id' => $ticket_id,
        'email_enviado' => $notificacion['success']
    ]);

} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'message' => 'Error al crear el ticket: ' . $e->getMessage()]);
}
?>
