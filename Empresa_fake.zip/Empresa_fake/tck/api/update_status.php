<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../config/database.php';

$ticket_id = $_POST['ticket_id'] ?? null;
$nuevo_estado = $_POST['estado'] ?? null;

if (!$ticket_id || !$nuevo_estado) {
    echo json_encode(['success' => false, 'message' => 'Faltan datos']);
    exit;
}

$conn = getConnection();

// Opcional: Validar orden de estados permitidos si deseas blindar el flujo
$estados_orden = ['Nuevo' => 1, 'En Progreso' => 2, 'Resuelto' => 3, 'Cerrado' => 4];

$stmt = $conn->prepare("SELECT estado FROM tck_tickets WHERE id = ?");
$stmt->bind_param("i", $ticket_id);
$stmt->execute();
$res = $stmt->get_result();
$ticket = $res->fetch_assoc();
$stmt->close();

if (!$ticket) {
    echo json_encode(['success' => false, 'message' => 'Ticket no encontrado']);
    exit;
}

$estado_actual = $ticket['estado'];

// Bloquear retroceso a nivel de servidor
if (isset($estados_orden[$nuevo_estado]) && isset($estados_orden[$estado_actual])) {
    if ($estados_orden[$nuevo_estado] < $estados_orden[$estado_actual]) {
        echo json_encode(['success' => false, 'message' => 'No está permitido retroceder de estado.']);
        exit;
    }
}

// Actualizar
$update = $conn->prepare("UPDATE tck_tickets SET estado = ? WHERE id = ?");
$update->bind_param("si", $nuevo_estado, $ticket_id);

if ($update->execute()) {
    echo json_encode(['success' => true, 'message' => 'Estado actualizado correctamente']);
} else {
    echo json_encode(['success' => false, 'message' => 'Error al actualizar en la base de datos']);
}

$update->close();
$conn->close();
?>
