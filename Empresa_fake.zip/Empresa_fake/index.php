
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Equipo de Sistemas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>
<body class="bg-light d-flex flex-column min-vh-100">


<div class="container my-auto py-5 text-center">
    <h1 class="fw-bold text-dark mb-2">Equipo de Sistemas</h1>
    <p class="text-muted mb-5">Accede rápidamente a las herramientas disponibles</p>
    
    <div class="row justify-content-center g-4">
        
        <div class="col-md-4">
            <div class="card shadow border-0 h-100 py-4 px-3 rounded-4">
                <div class="card-body d-flex flex-column align-items-center">
                    <div class="bg-primary bg-opacity-10 p-3 rounded-circle text-primary mb-3">
                        <i class="bi bi-file-earmark-text fs-2"></i>
                    </div>
                    <h5 class="fw-bold text-dark">Requerimientos de Sistemas</h5>
                    <p class="text-muted small mb-4">Gestión y control de solicitudes internas.</p>
                    <a href="../Empresa_fake/rq/index.php" class="mt-auto btn btn-primary btn-sm w-100 py-2 fw-semibold shadow-sm">Ingresar</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card shadow border-0 h-100 py-4 px-3 rounded-4">
                <div class="card-body d-flex flex-column align-items-center">
                    <div class="bg-danger bg-opacity-10 p-3 rounded-circle text-danger mb-3">
                        <i class="bi bi-ticket-detailed fs-2"></i>
                    </div>
                    <h5 class="fw-bold text-dark">Tickets a Sistemas</h5>
                    <p class="text-muted small mb-4">Soporte y reporte de incidencias técnicas.</p>
                    <a href="../Empresa_fake/rq/index.php" class="mt-auto btn btn-danger btn-sm w-100 py-2 fw-semibold text-white shadow-sm" style="background-color: #b60a0a;">Ingresar</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card shadow border-0 h-100 py-4 px-3 rounded-4">
                <div class="card-body d-flex flex-column align-items-center">
                    <div class="bg-warning bg-opacity-10 p-3 rounded-circle text-warning mb-3">
                        <i class="bi bi-people fs-2"></i>
                    </div>
                    <h5 class="fw-bold text-dark">Gestionar Cuentas</h5>
                    <p class="text-muted small mb-4">Administración de usuarios y permisos.</p>
                    <a href="../Empresa_fake/rq/index.php??" class="mt-auto btn btn-warning btn-sm w-100 py-2 fw-semibold shadow-sm" >Ingresar</a>
                </div>
            </div>
        </div>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>